---
name: New Issue
about: Use this template when creating an issue
title: ''
labels: ''
assignees: ''
---

<!-- IF describing a bug you must include all relevant information, like the code, language, compiler, screenshots  etc. -->

<!-- Please fill the information required below, or the issue will be closed.  -->

**Extension Version:** <replace with extension version>

**VS Code Version:** <replace with VS Code version>

**Browser Version:** <replace with browser version>

**Operating System:** <replace with OS name, version, and arch ( 32 bit or 64
bit )>
